#ifndef Debug_h
#define Debug_h
	class Debug {
	public:
		static void lastException();
	};
#endif
