/*
 * wificonnect.h
 *
 *  Created on: Nov 16, 2015
 *      Author: kolban
 */

#ifndef WIFICONNECT_H_
#define WIFICONNECT_H_

void wifiConnect(char *ssid, char *password, void (*callback)());

#endif /* WIFICONNECT_H_ */
