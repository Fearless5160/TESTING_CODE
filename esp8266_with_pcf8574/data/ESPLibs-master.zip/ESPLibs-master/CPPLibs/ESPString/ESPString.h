#ifndef ESPString_h
#define ESPString_h
class ESPString {
public:
	ESPString(char *data);
private:
	char *m_pData;
};
#endif
